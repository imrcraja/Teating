package com.mdeai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

val MdeBg = Color(0xFF000216)
val MdeCard = Color(0xFF0A0F2E)
val MdeMuted = Color(0xFF8FA3C8)

private val MdeScheme = darkColorScheme(
    background = MdeBg, surface = MdeBg, surfaceVariant = MdeCard,
    primary = Color(0xFF7C4DFF), secondary = Color(0xFF29B6F6),
    onBackground = Color.White, onSurface = Color.White, onPrimary = Color.White
)

@Composable
fun MdeTheme(content: @Composable () -> Unit) =
    MaterialTheme(colorScheme = MdeScheme, content = content)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MdeTheme {
                var showSplash by remember { mutableStateOf(true) }
                Box(Modifier.fillMaxSize().background(MdeBg)) {
                    if (showSplash) Splash { showSplash = false } else ChatScreen()
                }
            }
        }
    }
}

/* ---------- Logo: kaam ke waqt animation, baaki time normal logo ---------- */

@OptIn(UnstableApi::class)
@Composable
fun LogoLoop(modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val player = remember {
        ExoPlayer.Builder(ctx).build().apply {
            setMediaItem(MediaItem.fromUri("android.resource://${ctx.packageName}/${R.raw.mde_logo_loop}"))
            repeatMode = Player.REPEAT_MODE_ALL
            volume = 0f
            playWhenReady = true
            prepare()
        }
    }
    DisposableEffect(Unit) { onDispose { player.release() } }
    Box(modifier.background(MdeBg)) {
        AndroidView(
            factory = {
                PlayerView(it).apply {
                    this.player = player
                    useController = false
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                    setShutterBackgroundColor(0xFF000216.toInt())
                    setBackgroundColor(0xFF000216.toInt())
                }
            },
            modifier = Modifier.fillMaxSize()
        )
        // kinaare app ke background me ghul jayen
        Box(Modifier.fillMaxSize().background(
            Brush.radialGradient(0.70f to Color.Transparent, 1f to MdeBg)))
    }
}

@Composable
fun StaticLogo(modifier: Modifier = Modifier) {
    Box(modifier.background(MdeBg)) {
        Image(
            painterResource(R.drawable.mde_logo), null,
            Modifier.fillMaxSize(), contentScale = ContentScale.Crop
        )
        Box(Modifier.fillMaxSize().background(
            Brush.radialGradient(0.70f to Color.Transparent, 1f to MdeBg)))
    }
}

@Composable
fun BotLogo(working: Boolean, size: Dp = 64.dp) {
    val m = Modifier.size(size)
    if (working) LogoLoop(m) else StaticLogo(m)
}

/* ---------- Splash: sirf logo, animation nahi ---------- */

@Composable
fun Splash(onDone: () -> Unit) {
    LaunchedEffect(Unit) { delay(1800); onDone() }
    Column(
        Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        StaticLogo(Modifier.size(220.dp))
        Spacer(Modifier.height(12.dp))
        Text("MDE AI", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text("AI Mod Builder for Minecraft", color = MdeMuted, fontSize = 13.sp)
    }
}

/* ---------- Chat screen (demo): bot ko input mile to logo animate hota hai ---------- */

data class Msg(val fromUser: Boolean, val text: String)
data class Step(val text: String, val done: Boolean)

@Composable
fun ChatScreen() {
    val msgs = remember { mutableStateListOf<Msg>() }
    val steps = remember { mutableStateListOf<Step>() }
    var working by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    fun send() {
        val t = input.trim()
        if (t.isEmpty() || working) return
        msgs.add(Msg(true, t))
        input = ""
        working = true
        scope.launch {
            steps.clear()
            // Yahan baad me asli AI ka kaam judega. Abhi demo steps hain.
            val plan = listOf(
                "Prompt samajh raha hoon",
                "Loader aur version check kar raha hoon",
                "Templates chun raha hoon",
                "Code likh raha hoon"
            )
            for (p in plan) {
                steps.add(Step(p, false))
                delay(1300)
                steps[steps.lastIndex] = Step(p, true)
            }
            msgs.add(Msg(false, "Demo jawab: yahan MDE AI ka asli output aayega."))
            working = false
        }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            BotLogo(working, 64.dp)
            Spacer(Modifier.width(12.dp))
            Column {
                Text("MDE AI", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(if (working) "Kaam kar raha hoon..." else "Taiyar",
                    color = MdeMuted, fontSize = 13.sp)
            }
        }

        if (working || steps.isNotEmpty()) {
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp)
                    .background(MdeCard, RoundedCornerShape(12.dp)).padding(12.dp)
            ) {
                steps.forEach {
                    Text(
                        (if (it.done) "✓ " else "… ") + it.text,
                        color = if (it.done) MdeMuted else Color.White, fontSize = 13.sp
                    )
                }
            }
        }

        LazyColumn(
            Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item { Spacer(Modifier.height(8.dp)) }
            items(msgs) { m ->
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start
                ) {
                    Text(
                        m.text, color = Color.White, fontSize = 15.sp,
                        modifier = Modifier
                            .background(
                                if (m.fromUser) Color(0xFF3B2A8F) else MdeCard,
                                RoundedCornerShape(14.dp)
                            )
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    )
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = input, onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Mod ka detailed prompt likho...") },
                maxLines = 4
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = { send() }, enabled = !working) { Text("Bhejo") }
        }
    }
}
